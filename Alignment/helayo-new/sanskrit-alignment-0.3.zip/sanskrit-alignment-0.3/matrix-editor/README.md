This matrix editor opens CSV and TEICorpus XML files.
